package proyectofinaldatos2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Escritor {

    public void escribir(String str, String dataset) throws IOException {
        FileWriter fw;
        fw = new FileWriter("C:\\Users\\Castrillon\\Documents\\UNIVERSIDADJAVA\\" +
            "PROYECTOFINALDATOS2\\src\\test\\respuesta"+dataset.substring(7, dataset.length())
        );
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(str);
        bw.close();
    }

}
