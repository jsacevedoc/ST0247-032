package proyectofinaldatos2;

import java.util.LinkedList;

public class Vertices {

    LinkedList<Arcos> listica;
    int id;
    int costoDestino;

    public Vertices(int id, int costoDestino) {
        this.id = id;
        this.costoDestino = costoDestino;
        listica = new LinkedList<>();
    }

    public int getId(){
        return this.id;
    }

    public int getCostoDestino(){ return this.costoDestino; }

}
