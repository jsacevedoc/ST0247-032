package proyectofinaldatos2;

import java.util.LinkedList;

public class Coche {

    LinkedList<Integer> verticesEnCoche;
    int costoMaximo;

    public Coche(LinkedList<Integer> verticesEnCoche, int costoMaximo){
        this.verticesEnCoche = verticesEnCoche;
        this.costoMaximo = costoMaximo;
    }

}
