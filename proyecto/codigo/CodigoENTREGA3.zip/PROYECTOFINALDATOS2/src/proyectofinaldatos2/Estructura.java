package proyectofinaldatos2;

import java.util.*;

public class Estructura {

    int [][] matricia;
    double p;

    public Estructura(int [][] matricia, double p){
        this.matricia = matricia;
        this.p = p;
    }

    public Vertices[] asignarObjetoEnArreglo() {

        Vertices[] arregloVertices = new Vertices[matricia.length-2];

        for (int i = 2; i < matricia.length; i++) {
            int pesollegado = matricia[i][1];
            Vertices nuevoVert = new Vertices(i, pesollegado);
            arregloVertices[i-2] = nuevoVert;
        }
        return arregloVertices;
    }

    public Vertices[] asignarEnObjeto(Vertices[] arregloVertices){
        for(int i = 2; i<matricia.length; i++){
            for (int j = 2; j<matricia[i].length; j++){
                if(i!=j){
                    Arcos nuevoArco = new Arcos(j, matricia[i][j], matricia[1][j]);
                    arregloVertices[i-2].listica.add(nuevoArco);
                }
            }
        }

        return arregloVertices;
    }

    public Vertices[] ordenarArregloVertices(Vertices[] arregloVertices) {
        Arrays.sort(arregloVertices, Comparator.comparing(Vertices::getCostoDestino).reversed());

        return arregloVertices;
    }

    public Vertices[] ordenarLinkedList(Vertices[] arregloVertices){
        for (int i = 0; i<arregloVertices.length; i++) {
            Collections.sort(arregloVertices[i].listica, Comparator.comparingInt(Arcos::getCosto));
        }

        return arregloVertices;
    }


    public String direccionEnHashMap(Vertices[] arregloVertices) {


        HashMap<Integer, Integer> mapita = new HashMap<>();

        for (int i = 0; i < arregloVertices.length; i++) {
            mapita.put(arregloVertices[i].id, i);
        }

        return asignarCoches(mapita, arregloVertices);

    }

    public String asignarCoches(HashMap<Integer, Integer> mapita, Vertices[] arregloVertices){

        String strRespuesta = "P= "+p+"\n";
        boolean[] visitados = new boolean[arregloVertices.length+2];
        int contador = 1;

        for (int i = 0; i<arregloVertices.length; i++){
            if (!visitados[arregloVertices[i].getId()]){
                LinkedList<Integer> verticesEnCoche = new LinkedList<>();
                int acomulado = 0;
                int k = i;
                double condicion = arregloVertices[k].costoDestino * p;
                int currentCoche = 0;
                strRespuesta += "---------------NUEVO COCHE----#" + contador + "---------------" + "\n";
                while(acomulado + arregloVertices[k].costoDestino  <= condicion && verticesEnCoche.size() < 5 ) {
                    verticesEnCoche.add(arregloVertices[k].id);
                    if (verticesEnCoche.getLast() != currentCoche) {
                        currentCoche = verticesEnCoche.getLast();
                        strRespuesta += "Id: " + arregloVertices[k].id + "\n";
                        visitados[arregloVertices[k].getId()] = true;
                        for (Arcos listica : arregloVertices[k].listica) {
                            if (!visitados[listica.getIdlleg()]) {
                                if (verticesEnCoche.size() < 5) {
                                    acomulado += listica.costo;
                                } else if (verticesEnCoche.size() == 5) {
                                    acomulado += arregloVertices[k].costoDestino;
                                }
                                k = mapita.get(listica.getIdlleg());
                                break;
                            }
                        }
                    }
                }
                contador++;
            }
        }
        strRespuesta += "------------------------------------------------";
        return strRespuesta;
    }
}
