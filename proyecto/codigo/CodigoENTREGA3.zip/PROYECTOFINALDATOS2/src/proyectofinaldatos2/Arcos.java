package proyectofinaldatos2;

public class Arcos {

    int costoDestino;
    int idlleg;
    int costo;
    
    public Arcos(int idlleg, int costo, int costoDestino){

        this.idlleg=idlleg;
        this.costo=costo;
        this.costoDestino=costoDestino;
    }

    public int getIdlleg(){
        return this.idlleg;
    }

    public int getCosto(){
        return this.costo;
    }

}
