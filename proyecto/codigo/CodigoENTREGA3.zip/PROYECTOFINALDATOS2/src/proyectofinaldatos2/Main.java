package proyectofinaldatos2;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {

        try{
            System.out.println("--------------INICIO DEL PROCESO---------------");
            long TInicio, TFin, tiempo;
            TInicio = System.currentTimeMillis();

            Lector nuevoLector = new Lector();
            Escritor nuevoEscritor = new Escritor();
            String dataset = "dataset-ejemplo-U=205-p=1.3.txt";

            int[][] matrAux = nuevoLector.leerArchivo("C:\\Users\\Castrillon\\Documents\\UNIVERSIDADJAVA\\" +
                    "PROYECTOFINALDATOS2\\" + "src\\test\\"+dataset
            );

            double p = nuevoLector.p;

            Estructura est = new Estructura(matrAux, p);

            Vertices[] arrVertAux = (est.ordenarLinkedList(est.ordenarArregloVertices(est.asignarEnObjeto(
                    est.asignarObjetoEnArreglo())))
            );

            nuevoEscritor.escribir(est.direccionEnHashMap(arrVertAux), dataset);

            System.out.println("--------------PROCESO TERMINADO----------------");

            TFin = System.currentTimeMillis();
            tiempo = TFin - TInicio;
            System.out.println("Tiempo de ejecución en milisegundos: " + tiempo);
        }
        catch(Exception e){
            System.out.println("No se realizó el proceso");
            System.out.println(e);
        }
    }
}
